<?php
    ini_set("display_errors",1);
    error_reporting(E_ALL);
    
    date_default_timezone_set("America/Argentina/Buenos_Aires");
    $ahora=date("d/m/Y H:i:s",time());
    //echo $ahora;
?>